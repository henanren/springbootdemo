package com.laomn.mq.receiver;

import io.netty.channel.Channel;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.laomn.netty.client.OuterClient;
import com.laomn.utils.Constants;

@Component
@RabbitListener(queues = Constants.RECEIVE_QUEUE)
// @RabbitListener(queues = Constants.SEND_QUEUE)
public class MsgReceiver {
	@Autowired
	private OuterClient outerClient;

	@RabbitHandler
	public void process(String msg) {
		System.out.println("Receiver  : " + msg);
		String customer_no = "123456";
		// TODO 同步
		Channel channel = Constants.CUSTOMER_CHANNEL_CACHE.get(customer_no);
		if (channel != null) {
			channel.writeAndFlush(msg);
		}

		// TODO 异步
		outerClient.setMsg(msg);
		// outerClient.connect(port, host);
	}
}